﻿namespace MountainViewReports
{
    partial class MountainView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crvReports = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.btnRoomUtilReport = new System.Windows.Forms.Button();
            this.btnPhysicianPatient = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // crvReports
            // 
            this.crvReports.ActiveViewIndex = -1;
            this.crvReports.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crvReports.Cursor = System.Windows.Forms.Cursors.Default;
            this.crvReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crvReports.Location = new System.Drawing.Point(0, 0);
            this.crvReports.Margin = new System.Windows.Forms.Padding(4);
            this.crvReports.Name = "crvReports";
            this.crvReports.Size = new System.Drawing.Size(1161, 554);
            this.crvReports.TabIndex = 0;
            this.crvReports.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // btnRoomUtilReport
            // 
            this.btnRoomUtilReport.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoomUtilReport.Location = new System.Drawing.Point(635, 0);
            this.btnRoomUtilReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnRoomUtilReport.Name = "btnRoomUtilReport";
            this.btnRoomUtilReport.Size = new System.Drawing.Size(136, 38);
            this.btnRoomUtilReport.TabIndex = 1;
            this.btnRoomUtilReport.Text = "Room Utilization";
            this.btnRoomUtilReport.UseVisualStyleBackColor = true;
            this.btnRoomUtilReport.Click += new System.EventHandler(this.btnRoomUtilReport_Click);
            // 
            // btnPhysicianPatient
            // 
            this.btnPhysicianPatient.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhysicianPatient.Location = new System.Drawing.Point(789, 0);
            this.btnPhysicianPatient.Margin = new System.Windows.Forms.Padding(4);
            this.btnPhysicianPatient.Name = "btnPhysicianPatient";
            this.btnPhysicianPatient.Size = new System.Drawing.Size(135, 38);
            this.btnPhysicianPatient.TabIndex = 2;
            this.btnPhysicianPatient.Text = "Physician-Patient";
            this.btnPhysicianPatient.UseVisualStyleBackColor = true;
            this.btnPhysicianPatient.Click += new System.EventHandler(this.btnPhysicianPatient_Click);
            // 
            // MountainView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1161, 554);
            this.Controls.Add(this.btnPhysicianPatient);
            this.Controls.Add(this.btnRoomUtilReport);
            this.Controls.Add(this.crvReports);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MountainView";
            this.ShowIcon = false;
            this.Text = "Mountain View Reports";
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crvReports;
        private System.Windows.Forms.Button btnRoomUtilReport;
        private System.Windows.Forms.Button btnPhysicianPatient;
    }
}

