﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MountainViewReports
{
    public partial class MountainView : Form
    {
        public MountainView()
        {
            InitializeComponent();
        }

        private void btnRoomUtilReport_Click(object sender, EventArgs e)
        {
            MountainViewReports.CrystalReport.crptRoomUtilizationReport crptRoomUtilizationReport = new CrystalReport.crptRoomUtilizationReport();
            crvReports.ReportSource = null;
            crvReports.ReportSource = crptRoomUtilizationReport;
        }

        private void btnPhysicianPatient_Click(object sender, EventArgs e)
        {
            MountainViewReports.CrystalReport.crptPhysicianPatientReport crptPhysicianPatientReport = new CrystalReport.crptPhysicianPatientReport();
            crvReports.ReportSource = null;
            crvReports.ReportSource = crptPhysicianPatientReport;
        }
    }
}
