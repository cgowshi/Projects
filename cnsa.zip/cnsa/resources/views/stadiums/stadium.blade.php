
  <div class="card-deck">
    <div class="card" style="width: 25rem; height: 10rem">
      <div class="card-body">
        <h5 class="card-title">{{ $stadium->stadiumname }}</h5>
        <p class="card-text">{{ $stadium->location }}</p>
        <p class="card-text">Maximum Capacity: {{ $stadium->maximumcapacity }}</p>
      </div>
    </div>
  </div>
  <div class="col-0.5">
  </div>
