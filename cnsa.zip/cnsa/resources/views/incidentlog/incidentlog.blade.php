  <tr>
    <td>{{ $incidentlog->incidentlogid }}</td>
    <td>{{ $incidentinfo->incident_description }}</td>
    <td>{{ $incidentlog->date }}</td>
    <td>{{ $incidentlog->player_id }}</td>
    <td>{{ $incidentlog->staff_id }}</td>
  </tr>
