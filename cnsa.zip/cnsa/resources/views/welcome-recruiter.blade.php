@extends ('master-recruiter')

@section ('body')
<form style="padding-top:50px">
  <div class="form-signin text-center"style="text-align: center;">
        <h1>Welcome CNSA Recruiters!</h1>

  </div>
</form>
@endsection
