<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Phoenix extends Model
{
    protected $table = 'team_info';
}
