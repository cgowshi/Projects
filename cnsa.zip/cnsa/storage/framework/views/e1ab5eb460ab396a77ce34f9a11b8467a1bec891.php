<?php $__env->startSection('body'); ?>

<form style="padding-top:10%; text-align: center;" >
  <h1>Game Info Show</h1>
  </br>
<div class="form-signin">
  <div>
    <div align="right">
     <a href="<?php echo e(route('gameinfo.create')); ?>" class="btn btn-primary">Add</a>
    </div>

  </div>
</br>
  <div class="row">
<table class="table table-striped">
<thead>
  <tr>
    <th scope="col">Game ID</th>
    <th scope="col">Home Team ID</th>
    <th scope="col">Away Team ID</th>
    <th scope="col">Attendance</th>
    <th scope="col">Date</th>
    <th scope="col">Duration</th>
  </tr>
</thead>
<tbody>
<?php $__currentLoopData = $gameinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($row->gameid); ?></td>
          <td><?php echo e($row->team_id); ?></td>
          <td><?php echo e($row->team_id); ?></td>
          <td><?php echo e($row->attendance); ?></td>
          <td><?php echo e($row->date); ?></td>
          <td><?php echo e($row->duration); ?></td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
  </div>
  <nav aria-label="...">
  <ul class="pagination">
    <li class="page-item disabled">
      <span class="page-link">Previous</span>
    </li>
    <li class="page-item active">
      <span class="page-link">
        1
        <span class="sr-only">(current)</span>
      </span>
    </li>
    <li class="page-item"><a class="page-link" href="">2</a></li>
    <li class="page-item"><a class="page-link" href="">3</a></li>
    <li class="page-item">
      <a class="page-link" href="">Next</a>
    </li>
  </ul>
</nav>
</div>
</br>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>