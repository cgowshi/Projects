<?php $__env->startSection('body'); ?>
<form style="padding-top:200px">
  <div class="form-signin text-center">
    <div class="form-row">
      <label for="lblIncidentLog">Create Incident Log</label>
    </div>
  <div class="form-group row">
      <label for="inputIncidentLog">Incident Log</label>
      <input type="text" class="form-control" id="inputIncidentLog" placeholder="Incident Log" readonly>
  </div>
  <div class="form-group row">
    <label for="inputIncidentCode">Incident Code</label>
    <input type="text" class="form-control" id="inputIncidentCode" placeholder="Incident Code">
  </div>
  <div class="form-group row">
    <label for="inputDate">Date</label>
    <input type="date" class="form-control" id="inputDate">
  </div>
  <div class="form-group row">
    <label for="inputPlayerID">Player ID</label>
    <input type="text" class="form-control" id="inputPlayerID" placeholder="Player ID" readonly>
  </div>
  <div class="form-group row">
    <label for="inputStaffID">Staff ID</label>
    <input type="text" class="form-control" id="inputStaffID" placeholder="Staff ID" readonly>
  </div>

  <div class="form-group row">
    <div class="form-group col-md-12">
      <button type="submit" class="btn btn-primary">Create</button>
    </div>
  </div>

  <div class="form-group row">
    <div class="form-group col-md-12">
      <button type="button" class="btn btn-code">Code Description</button>
    </div>
  </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>