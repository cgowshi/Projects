  <tr>
    <td><?php echo e($incidentlog->incidentlogid); ?></td>
    <td><?php echo e($incidentlog->incident_code); ?></td>
    <td><?php echo e($incidentlog->date); ?></td>
    <td><?php echo e($incidentlog->player_id); ?></td>
    <td><?php echo e($incidentlog->staff_id); ?></td>
  </tr>
