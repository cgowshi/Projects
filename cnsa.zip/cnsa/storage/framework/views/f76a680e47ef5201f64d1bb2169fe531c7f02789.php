<?php $__env->startSection('body'); ?>

<form style="padding-top:55%; text-align: center;" >
  <h1>Player History</h1>
  </br>
<div class="form-signin">
  <div>
    <div align="right">
     <a href="<?php echo e(route('player.history.create')); ?>" class="btn btn-primary">Add</a>
    </div>

  </div>
</br>
  <div class="row">
<table class="table table-striped">
<thead>
  <tr>
    <th scope="col">Player History ID</th>
    <th scope="col">Player ID</th>
    <th scope="col">Team ID</th>
    <th scope="col">Year Joined</th>
    <th scope="col">Position Code</th>
  </tr>
</thead>
<tbody>
  <?php $__currentLoopData = $playershistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($row['playerhistoryid']); ?></td>
          <td><?php echo e($row['player_id']); ?></td>
          <td><?php echo e($row['team_id']); ?></td>
          <td><?php echo e($row['yearjoined']); ?></td>
          <td><?php echo e($row['[position_code]']); ?></td>
          <td><a href="<?php echo e(action('PlayersHistoryController@edit', $row['playerhistoryid'])); ?>" class="btn btn-warning">Edit</td>
        </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
  </div>
  <nav aria-label="...">
  <ul class="pagination">
    <li class="page-item disabled">
      <span class="page-link">Previous</span>
    </li>
    <li class="page-item active">
      <span class="page-link">
        1
        <span class="sr-only">(current)</span>
      </span>
    </li>
    <li class="page-item"><a class="page-link" href="">2</a></li>
    <li class="page-item"><a class="page-link" href="">3</a></li>
    <li class="page-item">
      <a class="page-link" href="">Next</a>
    </li>
  </ul>
</nav>
</div>
</br>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>