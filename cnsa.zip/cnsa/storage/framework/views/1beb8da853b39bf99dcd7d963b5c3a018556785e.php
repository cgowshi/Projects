<?php $__env->startSection('body'); ?>
<div class="form-signin">
  <div class="row">
       <div class="col-md-2">
           <input type="text" class="p-3 mb-1 bg-danger text-white"  style="align:center;"value="13">
       </div>
       <div class="col-md-2">
           <input type="text" class="p-3 mb-2 bg-danger text-white" value="Jack Windsor">
       </div>
   </div>

  <div class="row">
    <div class="col-sm-3">
     <img src="/images/63.jpg" alt="..." height="200px;" width="160px;">
    </div>
    <div class="col-sm-1">

    </div>
    <div class="col">
      <div class="row">
        <div class="col-sm-6">
          <label for="inputDateofBirth">Date of Birth</label>
          <input type="date" id="start" name="trip-start" class="form-control">
        </div>

        <div class="col-sm-6">
          <label for="inputGender">Gender</label>
          <input type="text" class="form-control" id="inputGender" placeholder="Gender">
        </div>
      </div>

      <div class="row">
        <div class="col-sm-6">
        <label for="inputHeight">Height</label>
        <input type="text" class="form-control" id="inputHeight" placeholder="Height">
        </div>
        <div class="col-md-6">
         <label for="inputWeight">Weight</label>
         <input type="text" class="form-control" id="inputWeight" placeholder="Weight">
        </div>
      </div>

      <div class="row">
        <div class="col-sm-10">
        <label for="inputSchool">School</label>
        <input type="text" class="form-control" id="inputHeight" placeholder="School">
        </div>
      </div>

      </div>
    </div>
  </br>
<table class="table table-striped">
<thead>
  <tr>
    <th scope="col">#</th>
    <th scope="col">Year Joined</th>
    <th scope="col">Year End</th>
    <th scope="col">Team Name</th>
    <th scope="col">Position</th>
  </tr>
</thead>
<tbody>
  <tr>
    <th scope="row">1</th>
    <td>2014</td>
    <td>2015</td>
    <td>Team Pheonix</td>
    <td>Asistant Coach</td>
  </tr>
  <tr>
    <th scope="row">2</th>
    <td>2015</td>
    <td>2017</td>
    <td>Team Pheonix</td>
    <td>Head Coach</td>
  </tr>
  <tr>
    <th scope="row">3</th>
    <td>2018</td>
    <td>2020</td>
    <td>Team Dark Panther</td>
    <td>Head Coach</td>
  </tr>
</tbody>
</table>
  </div>
</div>
</br>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>