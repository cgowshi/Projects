<?php $__env->startSection('body'); ?>
<form style="padding-top:200px">
<div class="form-signin">
  <div class="row md-8">
    <div class="col">
      <select class="form-control" id="playerIDselect">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </div>
    <div class="col">
      <select class="form-control" id="incidentCodeselect">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </div>
    <div class="col">
        <input type="date" id="start" name="trip-start" class="form-control">
    </div>
    <div class="form-group col">
    <button type="submit" class="btn btn-primary">Search</button>
  </div>
  </div>
</br>
</br>
  <div class="row">
<table class="table table-striped">
<thead>
  <tr>
    <th scope="col">Incident Log ID</th>
    <th scope="col">Incident Code</th>
    <th scope="col">Date</th>
    <th scope="col">Player ID</th>
    <th scope="col">Staff ID</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td>2314</td>
    <td>015</td>
    <td>2019-02-03</td>
    <td>23</td>
    <td>45</td>
  </tr>
  <tr>
    <td>2314</td>
    <td>015</td>
    <td>2019-02-03</td>
    <td>23</td>
    <td>45</td>
  </tr>
  <tr>
    <td>2314</td>
    <td>015</td>
    <td>2019-02-03</td>
    <td>23</td>
    <td>45</td>
  </tr>
</tbody>
</table>
  </div>
  <nav aria-label="...">
  <ul class="pagination">
    <li class="page-item disabled">
      <span class="page-link">Previous</span>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item active">
      <span class="page-link">
        2
        <span class="sr-only">(current)</span>
      </span>
    </li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>
</div>
</br>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>