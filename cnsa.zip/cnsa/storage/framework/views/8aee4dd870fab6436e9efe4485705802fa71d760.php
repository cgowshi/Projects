<?php $__env->startSection('body'); ?>
<form style="padding-top:1500px; margin-left:210px;">
<div class="form-row">
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
        <img src="/images/DarkWolves.PNG" alt="Dark Wolf" style="width:480px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Dark Wolf</h5>
      </div>
    </div>
  </div>
  <div class="col-0.5">
  </div>
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
      <img src="/images/Falcon.JPG" alt="Imperial Falcon"  style="width:480px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Imperial Falcon</h5>
      </div>
    </div>
  </div>
  <div class="col-0.5">
  </div>
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
      <img src="/images/Mammoth.JPG" alt="Mammoth" style="width:480px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Mammoth</h5>
      </div>
    </div>
  </div>
  <div class="row-5">
  </div>
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
      <img src="/images/Panda.JPG" alt="Panda" style="width:500px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Panda</h5>
      </div>
    </div>
  </div>
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
      <img src="/images/Panthers.JPG" alt="Panthers" style="width:500px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Panthers</h5>
      </div>
    </div>
  </div>
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
      <img src="/images/Phoenix.JPG" alt="Phoenix" style="width:480px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Phoenix</h5>
      </div>
    </div>
  </div>
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
      <img src="/images/Rhinos.JPG" alt="Rhinos" style="width:500px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Rhinos</h5>
      </div>
    </div>
  </div>
  <div class="card-deck">
    <div class="card" style="width: 30rem; height: 42rem">
      <a href="/players/show">
      <img src="/images/Eindhoven Raptors.PNG" alt="Eindhoven Raptors" style="width:480px; height:600px;">
      </a>
      <div class="card-body">
        <h5 class="card-title">Eindhoven Raptors</h5>
      </div>
    </div>
  </div>
</div>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>