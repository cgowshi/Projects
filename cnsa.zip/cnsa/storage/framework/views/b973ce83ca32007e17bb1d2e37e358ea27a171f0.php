<?php $__env->startSection('body'); ?>
<form style="padding-top:120px">
  <div class="form-signin">
    <div class="row">
        <div class="col-md-2">
            <input type="text" class="p-3 mb-1 bg-danger text-white"  style="align:center;"value="34">
        </div>
        <div class="col-md-2">
            <input type="text" class="p-3 mb-2 bg-danger text-white" value="Coach David Brown">
        </div>
    </div>
  </br>
<div class="row">
  <div class="col-md-6">
    <img src="/images/logo.jpeg" alt="..." class="img-thumbnail" height="180px;" width="180px;">
  </div>
  <div class="col-md-6">
    <div class="row">
        <label for="inputFirstName">Position</label>
        <input type="text" class="form-control" id="inputPosition" placeholder="Position">
    </div>
    <div class="row">
        <label for="inputFirstName">Year</label>
        <input type="text" class="form-control" id="inputYear" placeholder="Year">
    </div>
      <div class="row">
        <label for="inputFirstName">Team</label>
        <input type="text" class="form-control" id="inputTeam" placeholder="Team">
      </div>
  </div>
</div>

</br>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Year Joined</th>
      <th scope="col">Year End</th>
      <th scope="col">Team Name</th>
      <th scope="col">Position</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>2014</td>
      <td>2015</td>
      <td>Team Pheonix</td>
      <td>Asistant Coach</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>2015</td>
      <td>2017</td>
      <td>Team Pheonix</td>
      <td>Head Coach</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>2018</td>
      <td>2020</td>
      <td>Team Dark Panther</td>
      <td>Head Coach</td>
    </tr>
  </tbody>
</table>
  </div>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>