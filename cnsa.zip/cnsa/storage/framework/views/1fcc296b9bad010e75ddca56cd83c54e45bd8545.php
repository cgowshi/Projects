<?php $__env->startSection('body'); ?>

<form style="padding-top:55%; text-align: center;" >
  <h1>Injury Log</h1>
  </br>
<div class="form-signin">
  <div>
    <div align="right">
     <a href="<?php echo e(route('injurylog.create')); ?>" class="btn btn-primary">Add</a>
    </div>

  </div>
</br>
  <div class="row">
<table class="table table-striped">
<thead>
  <tr>
    <th scope="col">Date</th>
    <th scope="col">Player ID</th>
    <th scope="col">Injury Description</th>
    <th scope="col">Edit</th>
  </tr>
</thead>
<tbody>
  <?php $__currentLoopData = $injurylogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($row['date']); ?></td>
          <td><?php echo e($row['player_id']); ?></td>
          <td><?php echo e($row['injurydescription']); ?></td>
          <td><a href="<?php echo e(action('InjuryLogController@edit', $row['injuryid'])); ?>" class="btn btn-warning">Edit</td>
        </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
  </div>
  <nav aria-label="...">
  <ul class="pagination">
    <li class="page-item disabled">
      <span class="page-link">Previous</span>
    </li>
    <li class="page-item active">
      <span class="page-link">
        1
        <span class="sr-only">(current)</span>
      </span>
    </li>
    <li class="page-item"><a class="page-link" href="">2</a></li>
    <li class="page-item"><a class="page-link" href="">3</a></li>
    <li class="page-item">
      <a class="page-link" href="">Next</a>
    </li>
  </ul>
</nav>
</div>
</br>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>