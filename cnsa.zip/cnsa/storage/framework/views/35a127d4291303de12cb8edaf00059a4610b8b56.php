<?php $__env->startSection('body'); ?>

<form method="POST" action="/login">
      <?php echo e(csrf_field()); ?>

<div class="form-login bg-dark text-white">
  <div class="text-center">
    <img class="mb-4" src="/images/logo2.jpg" alt="" width="110" height="130">
    <h1 class="h3 mb-3 font-weight-normal">Login</h1>
    <div class="mb-2">
      <label for="inputEmail" class="sr-only">Email address</label>
      <input type="email" id="inputEmail" class="form-login-control" placeholder="Email address" required autofocus>
   </div>
     <div class="mb-2">
       <label for="inputPassword" class="sr-only">Password</label>
       <input type="password" id="inputPassword" class="form-login-control" placeholder="Password" required>
     </div>


    <button class="btn btn-lg btn-primary bg-danger" type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2020</p>
  </div>

</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>