<?php $__env->startSection('body'); ?>
<form>
  <div class="form-signin text-center">
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="inputPlayerID">Player ID</label>
        <input type="text" class="form-control" id="inputCoachID" placeholder="Player ID" readonly>
      </div>
      <div class="form-group col-md-6">
        <label for="inputHeight">Height</label>
        <input type="text" class="form-control" id="inputHeight" placeholder="Height">
    </div>
    <div class="form-group col-md-6">
      <label for="inputFirstName">First Name</label>
      <input type="text" class="form-control" id="inputFirstName" placeholder="First Name">
  </div>
  <div class="form-group col-md-6">
    <label for="inputWeight">Weight</label>
    <input type="text" class="form-control" id="inputWeight" placeholder="Weight">
</div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputLastName">Last Name</label>
         <input type="text" class="form-control" id="inputFirstName" placeholder="Last Name">
    </div>
    <div class="form-group col-md-6">
      <label for="inputSchoolID">School ID</label>
      <input type="text" class="form-control" id="inputSchoolID" placeholder="School ID">
  </div>
    <div class="form-group col-md-6">
      <label for="inputDateofBirth">Date of Birth</label>
      <input type="date" id="start" name="trip-start" class="form-control">
  </div>

    <div class="orm-group col-md-6">
      <label for="uploadPicture">Profile Picture</label>
      <input type="file" class="form-control-file" id="uploadPicture">
    </div>
</div>

<div class="form-row">
<div class="form-group col-md-6">
    <label for="inputGender">Gender</label>
    <input type="text" class="form-control" id="inputGender" placeholder="Gender">
  </div>
</div>

  <div class="form-group row">
    <div class="form-group col-md-12">
    <button type="submit" class="btn btn-primary">Update</button>
  </div>
</div>
<?php $__env->stopSection(); ?>
</form>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>