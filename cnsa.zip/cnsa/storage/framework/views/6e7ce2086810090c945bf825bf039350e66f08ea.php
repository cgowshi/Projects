<?php $__env->startSection('body'); ?>
<form style="padding-top:50px">
  <div class="form-signin text-center"style="text-align: center;">
        <h1>Welcome CNSA Staff IT-Crew!</h1>

  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master-it', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>