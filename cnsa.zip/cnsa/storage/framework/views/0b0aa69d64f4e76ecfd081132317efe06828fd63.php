<?php $__env->startSection('body'); ?>
<form style="padding-top:100px;">
<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
  <li><img src="/images/data1/images/adobestock_984696521.jpg" alt="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION" title="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION" id="wows1_0"/></li>
  <li><a href="http://wowslider.net"><img src="/images/data1/images/soccerheadsball.png" alt="css image gallery" title="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION" id="wows1_1"/></a></li>
  <li><img src="/images/data1/images/soccersprintstack.jpg" alt="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION" title="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION" id="wows1_2"/></li>
</ul></div>
<div class="ws_bullets"><div>
  <a href="#" title="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION"><span><img src="/images/data1/tooltips/adobestock_984696521.jpg" alt="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION"/>1</span></a>
  <a href="#" title="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION"><span><img src="/images/data1/tooltips/soccerheadsball.png" alt="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION"/>2</span></a>
  <a href="#" title="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION"><span><img src="/images/data1/tooltips/soccersprintstack.jpg" alt="WELCOME TO CANADIAN NATIONAL SOCCER ASSOCIATION"/>3</span></a>
</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">html slider</a> by WOWSlider.com v9.0</div>
<div class="ws_shadow"></div>
</div>
<script type="text/javascript" src="js/wowslider.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!-- End WOWSlider.com BODY section -->
</br>
<div id="about" class="container-fluid" style="margin-left:200px;">
  <div class="row">
    <div class="col-lg-8">
      </br>
        <div class="form-signin"style="width:1000px;margin-left:230px;padding:10px;">
      <h2 style="text-align:center;">About Us</h2><hr><br>
      <h5>Canadian National Soccer Association CNSA is Canada's national
          governing body for soccer. CNSA supports the growth and advancement of soccer in Canada, from roots
          to high performance, and on a national scale, in cooperation with its members. Soccer is Canada's biggest participatory sport and
          is considered the country's fastest growing sport. Inside 1,200 clubs that serve in 13 provincial/territorial member organizations,
          there are almost 1,000,000 registered Canada Soccer active participants in Canada.
      </h5>
      <br>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-signal logo"></span>
    </div>
  </div>
  </div>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>