<?php $__env->startSection('body'); ?>
<form style="padding-top:350px; margin-left:120px;">
  <h1>All Stadiums Information</h1>
<div class="form-row">
  <?php $__currentLoopData = $stadium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stadiums): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo $__env->make('stadium.stadiums', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>