<?php $__env->startSection('content'); ?>

                    <form class="form-horizontal" method="POST" action="/login">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-login bg-dark text-white">
                          <div class="text-center">
                            <img class="mb-4" src="/images/logo2.jpg" alt="" width="110" height="130">
                            <h1 class="h3 mb-3 font-weight-normal">Login</h1>
                            <label for="inputUsercode" class="sr-only">User Code</label>

                            <div class="md-2">
                                <input type="text" name="usercode" class="form-login-control" placeholder="User Code" required autofocus>
                            </div>

                            <label for="inputPassword" class="sr-only">Password</label>

                            <div class="md-2">
                              <input type="password" name="password" class="form-login-control" placeholder="Password" required>
                            </div>

                  


                                <button type="submit" class="btn btn-lg btn-primary bg-danger">
                                    Login
                                </button>



                        </div>
                        </div>
                    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>