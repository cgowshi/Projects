<?php $__env->startSection('body'); ?>
<form style="padding-top:200px; margin-left:350px;">
<div class="form-row">
  <div class="card-deck">
    <div class="card" style="width: 40rem;">
      <img src="/images/teams1.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Durham College</h5>
        <p class="card-text">Oshawa, ON</p>
      </div>
    </div>

</div>
</div>
<br>
<div class="form-row">
  <div class="card-deck">
    <div class="card" style="width: 18rem;">
      <img src="/images/centennial.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Centennial College</h5>
        <p class="card-text">Oshawa, ON</p>
      </div>
    </div>
    <div class="card" style="width: 18rem;">
      <img src="/images/OTU.png" alt="Card image cap" height="200px" width="200px">
      <div class="card-body">
        <h5 class="card-title">York University</h5>
        <p class="card-text">Oshawa, ON</p>
      </div>
    </div>
      <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="/images/trent.jpg" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">Seneca College</h5>
          <p class="card-text">Oshawa, ON</p>
      </div>
    </div>
</div>
</div>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>