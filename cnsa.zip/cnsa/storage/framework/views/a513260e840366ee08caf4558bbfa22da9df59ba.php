<!-- <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top float">
  <img src="/images/logo.jpeg" alt="" height="75px;" width="73px;">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <h1>Canadian National Soccer Association                | </h1>
      </li>

      <li class="nav-item active">
        <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="">Teams <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Players <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/schools/show">Schools <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <button class="right-side-button" type="submit">Login</button>
      </li>
    </ul>
  </div>

</nav> -->
<nav class="navbar navbar-expand-md navbar-light bg-white fixed-top">
      <img src="/images/logo.jpeg" alt="" height="75px;" width="73px;">
      <a class="navbar-brand" href="#">Canadian National Soccer Association</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="">Teams <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="#">Players <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="/schools/show">Schools <span class="sr-only">(current)</span></a>
          </li>
        </ul>
          <div class="nav-right">
            <button type="submit" class="btn btn-danger navbar-btn login-btn">Login</button>
          </div>
      </div>
    </nav>
